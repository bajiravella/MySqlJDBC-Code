package mynee.baji;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class JDBCUtility {
	private static Connection connection;

	public static Connection getConnection() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mynee", "root", "baji007");
		return connection;
	}

}
