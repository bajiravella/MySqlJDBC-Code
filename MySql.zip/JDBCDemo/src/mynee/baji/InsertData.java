package mynee.baji;

import java.sql.PreparedStatement;

import com.mysql.jdbc.Connection;

public class InsertData {

	public static void main(String[] args) throws Exception {
		Connection connection = JDBCUtility.getConnection();
		String insertQuery = "insert into FLIPKART_TBL values(?,?,?)";
		PreparedStatement statement = connection.prepareStatement(insertQuery);
		statement.setInt(1, 2);
		statement.setString(2, "Ravella Ramu");
		statement.setLong(3, 9494234904l);
		int update = statement.executeUpdate();
		System.out.println("The No.Of Records Inserted are:" + update);

	}

}
