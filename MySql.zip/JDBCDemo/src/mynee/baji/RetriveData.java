package mynee.baji;

import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

public class RetriveData {

	public static void main(String[] args) throws Exception {
		String query = "SELECT *FROM FLIPKART_TBL";
		Connection connection = JDBCUtility.getConnection();
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		while (resultSet.next()) {
			System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2) + resultSet.getLong(3));
		}
		resultSet.close();
		statement.close();
		connection.close();
	}

}
